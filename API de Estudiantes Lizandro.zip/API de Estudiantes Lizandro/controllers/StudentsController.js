const express = require('express');
const router = express.Router();
const Student = require('../models/Student'); // Importa el modelo de Student

// Ruta para obtener una lista de estudiantes
router.get('/students', async (req, res) => {
  try {
    const students = await Student.find();
    res.json(students);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Ruta para crear un nuevo estudiante
router.post('/students', async (req, res) => {
  const { name, grades } = req.body;
  const student = new Student({ name, grades });
  try {
    const newStudent = await student.save();
    res.status(201).json(newStudent);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Otras rutas y controladores para operaciones CRUD...

module.exports = router;
