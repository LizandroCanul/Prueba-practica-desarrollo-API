const express = require('express');
const mongoose = require('mongoose');
const app = express();

const studentsController = require('./controllers/StudentsController');

app.use(express.json());

// Configura la conexión a la base de datos
mongoose.connect('mongodb://localhost/tu_base_de_datos', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Maneja los eventos de conexión y error
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'Error de conexión a la base de datos:'));
db.once('open', () => {
  console.log('Conexión exitosa a la base de datos');
});

app.use('/api', studentsController);

const PORT = process.env.PORT || 5002;

app.listen(PORT, () => {
  console.log(`Servidor en ejecución en el puerto ${PORT}`);
});
