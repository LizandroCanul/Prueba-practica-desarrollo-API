// models/Grade.js
const mongoose = require('mongoose');

const gradeSchema = new mongoose.Schema({
  course: { type: String, required: true },
  score: { type: Number, required: true },
});

module.exports = mongoose.model('Grade', gradeSchema);
